## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE, comment="#>")
library(mlsas)

## -----------------------------------------------------------------------------
d <- mlsas_example("mixed")
str(d$attributes)
fit <- mlsas(d$data, variables=d$variables, id=d$id,
             ntree=20, nperm=199, seed=2026,
             verbose=FALSE, progress=FALSE)
summary(fit)
head(as.data.frame(fit$local))

## ----map, fig.width=6, fig.height=5-------------------------------------------
plot(fit)

## -----------------------------------------------------------------------------
fit_separate <- mlsas(d$attributes, d$variables, d$id,
  spatial=d$spatial[nrow(d$spatial):1,], ntree=20, nperm=199,
  seed=2026, verbose=FALSE, progress=FALSE)
stopifnot(identical(fit$similarity, fit_separate$similarity) ||
          isTRUE(all.equal(unname(as.vector(fit$similarity)),
                           unname(as.vector(fit_separate$similarity)))))
w_rook <- mlsas_weights(d$data, id=d$id, contiguity="rook")
fit_weights <- mlsas(d$attributes, d$variables, d$id, weights=w_rook,
  ntree=20, nperm=199, seed=2026, verbose=FALSE, progress=FALSE)

## -----------------------------------------------------------------------------
s <- fit$similarity
o <- mlsas_stat(s, w_rook)
upper <- mlsas_local_test(o, alternative="greater", nperm=199,
                         seed=8, verbose=FALSE, progress=FALSE)
head(as.data.frame(upper))

